---
name: vibe-ai-footage
description: Ideabro Studio Vibe Editing System - turning AI-generated video clips (Veo, Sora, Kling, Runway, Pika, Hailuo, Luma, etc.) and mixed stock or phone footage into a finished film that doesn't look like AI. Use when the user has a folder of generated clips and wants a brand film, story short, AI music video, documentary-style piece, or faceless YouTube / Shorts channel video (script, AI voice, visuals, captions); when clips have morphing hands or faces, garbled text, objects popping in or out, flicker or mismatched looks; when shots must be retimed to land on narration; or when footage needs one consistent grade. Triggers on "AI clips", "Veo", "Sora", "Kling", "Runway", "make it not look AI", "brand film", "faceless channel", "AI video edit".
---

# AI Footage → Films That Don't Look AI
*Ideabro Studio · Vibe Editing System — direct the vibe, let AI do the keyframes.*

Generated clips are raw material, not a film. They come with morphs, warped text, drifting objects and inconsistent
looks. Your job is to **select ruthlessly, cut around flaws, retime to the story, unify the look, and carry
anything that must be precise (text, UI, logos, numbers) with real graphics**, then let sound design make it feel real.

Paths below are relative to **this skill's folder**: `scripts/`, `reference/`, `templates/`.

## What you can make here

| type | default |
|---|---|
| **Brand film** | 16:9 (+ 9:16 cut-down), 45–90 s, client VO or AI VO, cinematic/clean grade, rebuilt UI + logo graphics |
| **Story short / music video** | cut to the music bar grid, 1.5–3 s shots, consistent character look, title + credits |
| **Documentary-style piece** | narration-led, slow push-ins, archival-style grade, lower-thirds and serif titles |
| **Faceless YouTube / Shorts** | script → AI voice → visuals per sentence → pop captions → bed; templatised for a series |

## Step 0: Setup (first time in a project)

1. `python3 scripts/doctor.py --kit ai-footage --install` (Windows: `py`. If pip refuses, see `reference/troubleshooting.md`.)
2. `python3 scripts/new_project.py <name> --kind ai-footage --format 16:9 --fps 24` and work in it. Clips go in `raw/`.

## Step 1: Brief + rights

Ask: the story/message and audience · narration (user's recording, script for AI voice, or music only) · length and
formats · look (clean premium / cinematic / documentary / gritty) · brand assets (logo, colours, real photos of
people/products) · **rights**: was the footage generated on a plan that allows commercial use? Do they own the photos/music?
Visible generator watermarks are not ours to strip. Ask the user to export clean versions from their plan, or keep the mark.

## Step 2: QC every clip (don't skip)

```bash
python3 vibe/clipscan.py raw/          # sheets + cut/instability report -> work/scan/
```
Open **every** `work/scan/*_sheet.png` with the Read tool. In `work/scan/scan.md` fill the "usable" column with source
ranges and notes. Reject or cut around:
- morphing hands, faces, limbs; extra fingers; faces that change identity between frames
- garbled text, fake logos, nonsense UI on screens/signs
- objects appearing/disappearing, things passing through each other, melting geometry
- flicker, frame-to-frame colour pumping, sudden dissolves *inside* a clip
- the last 0.5–1 s of many generated clips (they often degrade or freeze)
Report to the user: which clips are strong, which are unusable, and what's missing (suggest prompts to regenerate,
or a graphic/photo to replace the shot).

## Step 3: Voice and paper edit

- Narration: `audio_kit.py voice raw/vo.mp3 -o work/vo.wav --denoise`, or AI voice `tts.py --script work/script.txt`.
- `python3 vibe/transcribe.py work/vo.wav -o work/words.json` → word times.
- **Paper edit** = beat table: each narration line → the shot that illustrates it, with source in/out. Shots of 1.5–4 s.
  Cut on the words that matter ("...and **this** changes everything" → cut on *this*).

## Step 4: Assemble

Write `work/edit.json` (shots in order, `in/out` from the scan, `dur` to land each shot exactly on its line) and:
```bash
python3 vibe/assemble.py work/edit.json -o work/assembly.mp4 --audio work/vo.wav
```
- `dur` stretches/squeezes a shot to fit (keep speed within 0.7–1.4× so motion still looks natural; `flow: true` for slow-mo).
- Stills/photos (real people, products) can be shots too: `{"file": "raw/ceo.jpg", "dur": 3, "zoom": 1.08}`.
- Transitions: mostly `cut`; `fade`/`dip` for time jumps and section changes.
- `work/assembly_timing.json` gives the output time of each shot, so cue graphics and SFX to it.

## Step 5: Fix what's left

| problem | fix |
|---|---|
| flaw in the middle of a good shot | split it into two shots around the flaw, or cover the moment with a cut-away/graphic |
| garbled text on a screen/sign | don't show it: crop/punch in past it, defocus that region (blur a box with an overlay), or **rebuild the screen as a vector UI graphic** (see `vibe-launch-ads` techniques) |
| fake logo | replace with the real logo graphic, tracked or as a clean end card |
| jitter/wobble | ffmpeg `deshake` (or `vidstab` 2-pass) on that shot |
| clip too short for the line | slow it (0.7×, `flow`) or hold a freeze-frame + push-in, or add a second angle |
| low resolution / soft | upscale with lanczos in `assemble` (automatic) + light `unsharp`; never upscale more than 2× |
| mismatched looks | one grade for everything, below |

## Step 6: Unify the look (this is what stops it looking like AI)

```bash
python3 vibe/grade.py work/assembly.mp4 --look clean-bright --strength 0.8 --grain 5 --vignette -o work/graded.mp4
```
- One look + the same strength on every shot; a little **grain** hides the AI-smooth "plastic" feel.
- Graphics (titles, UI, lower-thirds) get the same palette and are rendered as a transparent overlay
  (`S.render(..., alpha=True)` → `vibe/overlay.py`). Precise information lives in graphics, never in generated pixels.
- Add **imperfection**: subtle camera drift on locked-off AI shots (overlay scene can't move footage; use `zoom` in
  edit.json for slow push-ins), varied shot lengths, a real photo or real footage where possible.

## Step 7: Sound (half the realism)

Room tone/ambience under every scene, foley-like SFX on key actions (whoosh, impact, click, shutter), a `cinematic` or
`corporate` bed ducked under the VO, risers into reveals, silence before the big line. Build `work/cues.json`, then
`audio_kit.py mix … --video work/graded_overlay.mp4 --out-video out/<name>_v1.mp4`. Optional subtitles:
`captions.py work/words.json --style minimal` (cinematic) or `pop` (shorts).

## Faceless channel recipe (series-ready)

1. Script (60 s short): hook line, 3 points, CTA. Write as spoken. One sentence ≈ one shot.
2. `tts.py --script work/script.txt --voice am_michael` → `transcribe.py work/vo.wav`.
3. Visuals per sentence: AI clips (prompt list for the user to generate), motion-graphic cards (motion_kit), photos.
4. `assemble.py` → `captions.py --style pop --burn` → `audio_kit.py bed --mood tech` + mix → `export.py --preset shorts,reels`.
5. Save the pipeline as a script (`make_episode.py script.txt`) so the next episode is one command. For many episodes use
   the `vibe-bulk-videos` skill.

## Review and deliver

`python3 vibe/stills.py out/<name>_v1.mp4 --count 16` → READ it: no morphs or garbled text left in any frame, the grade is
consistent, and names/logos are correct. Then `export.py --preset youtube,reels --fit blur` (or crop with anchors). Write
`work/revisions.md` and keep each version.

## Quality bar

- [ ] Every frame checked for AI artifacts (hands, faces, text, popping objects); none left in the final
- [ ] All text/logos/UI/numbers are real graphics, correctly spelled
- [ ] One consistent grade + grain; no shot "jumps" in colour
- [ ] Shots land on narration words / music bars; nothing held so long it starts to degrade
- [ ] VO clear, ambience and SFX present, −14 LUFS
- [ ] Rights confirmed for clips, photos, music, voice

## Reference
`reference/foundations.md` · `reference/sound-design.md` · `reference/brand-kit.md` · `reference/motion-principles.md` ·
`reference/export-specs.md` · `reference/troubleshooting.md`
