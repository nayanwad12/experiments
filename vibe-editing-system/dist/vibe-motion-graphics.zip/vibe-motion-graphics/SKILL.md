---
name: vibe-motion-graphics
description: Ideabro Studio Vibe Editing System - motion graphics and motion design generated entirely in code. Use when the user wants a motion-design showreel, animated explainer, kinetic typography or lyric video, logo reveal / animated intro / outro, data or infographic video (animated charts, counters, stats, timelines), lower-third / title / transition packs exported with transparency for Premiere, CapCut or DaVinci, animated quote or carousel posts, before/after comparison animations, or abstract animated backgrounds and loops. Also for shader/WebGL looks rendered headlessly. Triggers on "motion graphics", "animate this", "kinetic type", "logo animation", "intro", "explainer", "infographic", "animated chart", "lower thirds", "title pack", "transition pack", "showreel".
---

# Motion Graphics
*Ideabro Studio · Vibe Editing System — direct the vibe, let AI do the keyframes.*

Every frame is a pure function of time `t`. You write `draw(c, t)` with motion_kit (skia vector graphics), and
the engine renders stills instantly, drafts fast, and finals in parallel on every CPU core. Timing and copy live in
`timeline.py`, so "make it snappier" or "change the word" is a one-line change.

Paths below are relative to **this skill's folder**: `scripts/`, `reference/`, `templates/`.

## What you can make here

| type | default |
|---|---|
| **Showreel / sizzle** | 16:9 or 9:16, 20–40 s, 128 BPM hype bed, a section per bar group, glitch/zoom transitions |
| **Explainer** | 16:9, 45–90 s, AI or recorded voiceover, icons + diagrams built on the words, calm corporate bed |
| **Kinetic typography / lyric video** | words land on the voice or beat (`words.json`), slams, staggers, highlight bars |
| **Logo reveal / intro / outro** | 3–6 s, logo assembled from shapes/mask, impact + sparkle, tagline |
| **Data / infographic** | animated bars, lines drawing on, counters, progress rings, timelines; numbers exact |
| **Lower-third / title / transition packs** | **transparent ProRes 4444 .mov** files usable in any editor |
| **Quote / carousel posts** | 1:1 or 4:5, 6–10 s loops, text builds, brand frame |
| **Before / after** | split-screen wipe, slider, counters for the improvement |
| **Loops & backgrounds** | seamless loops (animate with `sin(2π t / LOOP)`), liquid/gradient/grid motion |

## Step 0: Setup (first time in a project)

1. `python3 scripts/doctor.py --kit motion --install` (Windows: `py`. If pip refuses, see `reference/troubleshooting.md`.)
2. `python3 scripts/new_project.py <name> --kind motion --format 16:9 --fps 30 --duration 20`
   Work inside the new folder. Tools are in `vibe/`; `scene.py` + `timeline.py` are a working branded starter.
3. `python3 scene.py stills` and look at the stills, so you and the user see the pipeline working in about a minute.

## Step 1: Brief

Ask in one message (defaults in brackets): purpose + where it plays *(social, 9:16)* · length *(20 s)* ·
the words/data that must appear *(required)* · vibe words + references *(bold, clean, kinetic)* · brand *(Ideabro
house style)* · voiceover or music only? *(music only)*.

## Step 2: Design before animating

1. **Beat table** (`time | picture | sound | text`), on the BPM grid. One idea per section.
2. **Style frames:** draw the key frame of each section as a still first (`python3 scene.py stills 1.2 4.8 …`).
   Get approval on the look (layout, type, colour) **before** animating. Most revisions are about design, not motion.
3. Choose a motion language and stick to it: e.g. "snappy: `ease_out_expo` 0.35 s in, 0.2 s out, hard cuts on bars"
   or "smooth: `ease_in_out_cubic` 0.8 s, cross-dissolves".

## Step 3: Animate (motion_kit cheat sheet)

```python
from motion_kit import *          # in scene.py: sys.path.insert(0, "vibe")
k  = ease_out_back(prog(t, start, 0.45))            # 0→1 with overshoot
ki = stagger(lt, i, start=0.1, each=0.08, dur=0.4)   # i-th item of a build
b  = pulse(t, TL.BPM)                                # 1 on each beat, decays: bump scale/brightness
x  = lerp(a, b, ease_in_out_expo(prog(t, s, d)))
sh = 10*U*noise1(t*8)*math.exp(-8*max(0, t-hit))     # impact shake
text(c, "WORD", x, y, size=160*U, font="display", fill=rgb(B,"fg"), tracking=0.02)
rrect / circle / shadow / draw_image / wrap / text_width   # shapes, images, auto-fit text
c.save(); c.clipRect(skia.Rect.MakeXYWH(...)); ...; c.restore()   # masks and reveals
```
- **Kinetic type to a voice:** `python3 vibe/tts.py --script work/script.txt` (or record), then
  `python3 vibe/transcribe.py work/vo.wav`. Load `work/words.json` and trigger each word's animation at its `s`.
- **Charts:** draw bars as `rrect` with height `value * ease_out_cubic(prog(...))`; a line as a polyline drawn up to
  fraction k (use `skia.Path` + `skia.PathMeasure` → `getSegment`); counters with `f"{int(v):,}"`. Always label units and
  sources; numbers must be exactly what the user gave.
- **Logo reveal:** split the logo into parts (shapes or separate PNGs) and animate them in (scale/rotate/mask wipe);
  finish on the full logo + an impact SFX + a sparkle.
- **Transitions:** whip, iris, shape wipe, zoom-through, glitch. Recipes in `reference/motion-principles.md`.
- **Finishing:** `S.render(..., post=lambda a, t: grain(vignette(a, .25), .03, int(t*30)))` for a filmic texture.

**Transparent packs** (lower-thirds, titles, transitions, stickers): don't paint a background, then
`S.render(draw, "out/lowerthird_01.mov", alpha=True)` writes ProRes 4444 with alpha. Make one file per element
(each 3–6 s: in, hold, out), and add a contact sheet over a dark and a light background for the buyer/client.

**Shaders / WebGL / HTML (advanced):** copy `templates/web/` into the project as `web/`, then write the frame
in `window.renderFrame(t)` (Canvas2D, WebGL, SVG, Three.js, GSAP seeked to `t`...). Render:
`node web/render.mjs web/scene.html --w 1920 --h 1080 --fps 30 --dur 20 -o out/web.mp4 --audio work/mix.wav`
(needs `npm i playwright && npx playwright install chromium` once). Use this for GPU-shader looks (liquid, bloom,
particles in the thousands). Use motion_kit for everything else, because it's simpler and faster.

## Step 4: Sound, render, deliver

1. `python3 scene.py audio` (bed + SFX from `timeline.py`). Pops on builds, whooshes before transitions, impacts on reveals.
2. `python3 scene.py draft` → share timing → `python3 scene.py render`.
3. `python3 vibe/stills.py out/<name>.mp4 --count 12` → READ the sheet → `python3 vibe/export.py … --preset …`.

## Quality bar

- [ ] Style frames approved before full animation
- [ ] One consistent motion language (easings, durations, direction of travel)
- [ ] Nothing pops on or off without an ease (unless it's a deliberate hard cut on a beat)
- [ ] Text on screen long enough to read (0.3 s/word + 0.5 s) and never clipped by the frame
- [ ] Brand palette only; ≤ 2 typefaces; contrast checked on every still
- [ ] Loops are seamless (first and last frame identical); packs have clean alpha (check over dark AND light)
- [ ] Data is correct and labelled

## Reference
`reference/motion-principles.md` (easing, kinetic type, camera, transitions) · `reference/foundations.md` ·
`reference/brand-kit.md` · `reference/sound-design.md` · `reference/export-specs.md` · `reference/troubleshooting.md`
